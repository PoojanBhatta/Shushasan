
import { GoogleGenAI } from "@google/genai";

// Always use process.env.API_KEY directly for initialization as per guidelines.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function askCivicAssistant(query: string) {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: query,
      config: {
        systemInstruction: "You are 'Sushashan AI', a helpful assistant for Nepali citizens. Your goal is to improve transparency and accountability. You help users understand government budgets, local laws, and how to file complaints. Be polite, objective, and use easy-to-understand language. If the user asks about specific data not provided, encourage them to look at the 'Budget' or 'Projects' tabs.",
        tools: [{ googleSearch: {} }]
      },
    });
    
    return {
      // Access the .text property directly (not as a method).
      text: response.text,
      // Extract website URLs from groundingChunks when using googleSearch tool.
      sources: response.candidates?.[0]?.groundingMetadata?.groundingChunks || []
    };
  } catch (error) {
    console.error("Gemini Error:", error);
    return { text: "I'm sorry, I'm having trouble connecting to my knowledge base right now. Please try again later.", sources: [] };
  }
}

export async function summarizeCitizenFeedback(feedbackItems: any[]) {
  try {
    const prompt = `Summarize the following citizen feedback items into key themes and actionable points for the local government. Feedback data: ${JSON.stringify(feedbackItems)}`;
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        systemInstruction: "You are an expert analyst for local government. Provide concise, professional summaries that highlight major pain points and areas of improvement.",
      }
    });
    return response.text;
  } catch (error) {
    return "Could not generate summary at this time.";
  }
}
