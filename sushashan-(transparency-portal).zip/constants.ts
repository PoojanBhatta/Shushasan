
import { Project, BudgetEntry, Feedback, NewsItem, Commitment, Poll, LogEntry } from './types';

export const MOCK_PROJECTS: Project[] = [
  {
    id: 'p1',
    name: 'Kathmandu-Terai Fast Track',
    status: 'In Progress',
    budget: 175000000000,
    spent: 61250000000,
    completionPercentage: 35,
    ward: 0,
    description: 'A 72.5 km expressway linking Kathmandu to Nijgadh.',
    lastUpdated: '2024-05-20',
    isNationalPride: true,
    videoUrl: 'https://example.com/fast-track',
    documents: ['env_impact_v1.pdf', 'quarterly_report_may.pdf']
  },
  {
    id: 'p2',
    name: 'Digital Nepal Framework 2026',
    status: 'In Progress',
    budget: 5000000000,
    spent: 2250000000,
    completionPercentage: 45,
    ward: 0,
    description: 'Transforming Nepal into a digitally empowered society.',
    lastUpdated: '2024-05-18',
    isNationalPride: true
  },
  {
    id: 'p4',
    name: 'Ward 4 Smart Irrigation Project',
    status: 'In Progress',
    budget: 4500000,
    spent: 2925000,
    completionPercentage: 65,
    ward: 4,
    description: 'Modernizing agriculture for 500+ local farmers.',
    lastUpdated: '2024-05-15'
  }
];

export const MOCK_COMMITMENTS: Commitment[] = [
  {
    id: 'c1',
    officialName: 'Mayor Rajesh Man Singh',
    position: 'Mayor of Birgunj',
    promise: 'Installation of 500 solar street lights within the first year of tenure.',
    deadline: '2025-06-01',
    status: 'In Progress'
  },
  {
    id: 'c2',
    officialName: 'Minister of Health',
    position: 'National Cabinet',
    promise: 'Upgrading district hospital with 50 new ICU beds.',
    deadline: '2024-12-30',
    status: 'Pending'
  }
];

export const MOCK_POLLS: Poll[] = [
  {
    id: 'pl1',
    question: 'Where should we focus the next infrastructure budget?',
    options: [
      { text: 'Road Paving', votes: 1240 },
      { text: 'Public Parks', votes: 450 },
      { text: 'Drainage Systems', votes: 890 }
    ],
    totalVotes: 2580,
    endDate: '2024-06-15'
  }
];

export const MOCK_LOGS: LogEntry[] = [
  { id: 'l1', user: 'Admin_Ward4', action: 'Project Update', timestamp: '2024-05-22 10:15 AM', details: 'Updated completion percentage for Irrigation Project to 65%' },
  { id: 'l2', user: 'Fin_Officer_KMC', action: 'Budget Allocation', timestamp: '2024-05-21 02:45 PM', details: 'Allocated 5M NPR for Education Supplies.' }
];

export const MOCK_NEWS: NewsItem[] = [
  {
    id: 'n1',
    title: 'New Health Post in Ward 2',
    content: 'Construction of the primary health post is nearing completion, offering 24/7 emergency services.',
    date: '2024-05-21',
    location: 'Kathmandu-2'
  }
];

export const MOCK_BUDGET: BudgetEntry[] = [
  { id: 'b1', category: 'Infrastructure', allocated: 50000000, spent: 32000000, description: 'Roads, bridges, and public utilities.' },
  { id: 'b2', category: 'Education', allocated: 20000000, spent: 18500000, description: 'School supplies and teacher training.' },
  { id: 'b3', category: 'Healthcare', allocated: 35000000, spent: 21000000, description: 'Medical clinics and emergency response.' }
];

export const MOCK_FEEDBACK: Feedback[] = [
  {
    id: 'f1',
    userName: 'Kushal R.',
    type: 'Grievance',
    category: 'Sanitation',
    subject: 'Waste Disposal Timing',
    message: 'The garbage truck hasn\'t arrived in Ward 4 for 3 days.',
    timestamp: '2024-05-19T10:00:00Z',
    status: 'Reviewed'
  }
];
