
export type Language = 'Nepali' | 'English' | 'Maithili' | 'Bhojpuri';

export interface UserProfile {
  name: string;
  mobile: string;
  citizenship: string;
  dob: string;
  district: string;
  palika: string;
  isOfficial?: boolean;
}

export interface BudgetEntry {
  id: string;
  category: string;
  allocated: number;
  spent: number;
  description: string;
}

export interface Project {
  id: string;
  name: string;
  status: 'Planned' | 'In Progress' | 'Completed' | 'Delayed';
  budget: number;
  spent: number;
  completionPercentage: number;
  ward: number;
  description: string;
  lastUpdated: string;
  videoUrl?: string;
  isNationalPride?: boolean;
  documents?: string[];
}

export interface Commitment {
  id: string;
  officialName: string;
  position: string;
  promise: string;
  deadline: string;
  status: 'Pending' | 'In Progress' | 'Fulfilled' | 'Unfulfilled';
}

export interface Poll {
  id: string;
  question: string;
  options: { text: string; votes: number }[];
  totalVotes: number;
  endDate: string;
  userVoted?: boolean;
}

export interface LogEntry {
  id: string;
  user: string;
  action: string;
  timestamp: string;
  details: string;
}

export interface NewsItem {
  id: string;
  title: string;
  content: string;
  date: string;
  location: string;
  image?: string;
}

export interface Feedback {
  id: string;
  userName: string;
  type: 'Suggestion' | 'Concern' | 'Query' | 'Grievance';
  category: 'Health' | 'Education' | 'Infrastructure' | 'Sanitation' | 'Corruption' | 'Other';
  subject: string;
  message: string;
  timestamp: string;
  status: 'Submitted' | 'Reviewed' | 'Action Taken' | 'Addressed';
  attachments?: string[];
  isAnonymous?: boolean;
}

export enum AppView {
  DASHBOARD = 'DASHBOARD',
  BUDGET = 'BUDGET',
  PROJECTS = 'PROJECTS',
  COMMITMENTS = 'COMMITMENTS',
  PARTICIPATION = 'PARTICIPATION',
  LOGS = 'LOGS',
  ASSISTANT = 'ASSISTANT'
}
