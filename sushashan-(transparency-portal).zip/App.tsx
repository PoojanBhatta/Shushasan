
import React, { useState, useEffect } from 'react';
import { AppView, Project, BudgetEntry, Feedback, Language, UserProfile } from './types';
import { MOCK_PROJECTS, MOCK_BUDGET, MOCK_FEEDBACK } from './constants';
import { translations } from './translations';
import Dashboard from './components/Dashboard';
import BudgetOverview from './components/BudgetOverview';
import ProjectTracker from './components/ProjectTracker';
import FeedbackHub from './components/FeedbackHub';
import AICivicAssistant from './components/AICivicAssistant';
import LoginPortal from './components/LoginPortal';
import CommitmentTracker from './components/CommitmentTracker';
import CivicPolls from './components/CivicPolls';
import TransparencyLog from './components/TransparencyLog';
import Logo from './components/Logo';

const App: React.FC = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [language, setLanguage] = useState<Language>('Nepali');
  const [activeView, setActiveView] = useState<AppView>(AppView.DASHBOARD);
  const [notifications, setNotifications] = useState<string[]>(['New budget published for Ward 4', 'Fast Track project updated']);
  
  const [projects] = useState<Project[]>(MOCK_PROJECTS);
  const [budget] = useState<BudgetEntry[]>(MOCK_BUDGET);
  const [feedbacks, setFeedbacks] = useState<Feedback[]>(MOCK_FEEDBACK);

  useEffect(() => {
    const saved = localStorage.getItem('sushashan_logged_in');
    const savedProfile = localStorage.getItem('sushashan_profile');
    if (saved === 'true' && savedProfile) {
      setIsLoggedIn(true);
      setProfile(JSON.parse(savedProfile));
    }
  }, []);

  const handleLogin = (newProfile: UserProfile) => {
    setIsLoggedIn(true);
    setProfile(newProfile);
    localStorage.setItem('sushashan_logged_in', 'true');
    localStorage.setItem('sushashan_profile', JSON.stringify(newProfile));
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setProfile(null);
    localStorage.removeItem('sushashan_logged_in');
    localStorage.removeItem('sushashan_profile');
  };

  if (!isLoggedIn) {
    return <LoginPortal onLogin={handleLogin} />;
  }

  const t = translations[language];
  const profileImageUrl = `https://api.dicebear.com/7.x/avataaars/svg?seed=RamBahadurThapa&backgroundColor=b6e3f4&style=circle`;

  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-[#f8fafc] font-sans selection:bg-blue-100">
      {/* Desktop Sidebar */}
      <aside className="hidden md:flex flex-col w-72 bg-slate-950 border-r border-slate-900 p-6 fixed h-full shadow-2xl z-30 text-white">
        <div className="flex items-center gap-4 mb-12 px-2">
          <div className="w-16 h-16 bg-white rounded-3xl flex items-center justify-center shadow-lg shrink-0">
            <Logo className="w-12 h-12" />
          </div>
          <div className="flex flex-col">
            <h1 className="text-2xl font-black tracking-tight leading-none text-white">सुशासन</h1>
            <p className="text-[10px] text-blue-400 font-bold uppercase tracking-[0.2em] mt-1 opacity-80">Citizen Connect</p>
          </div>
        </div>

        <nav className="flex-1 space-y-1.5 overflow-y-auto pr-2 no-scrollbar">
          <div className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-4 px-4">Governance</div>
          <SidebarLink view={AppView.DASHBOARD} activeView={activeView} setActiveView={setActiveView} icon="fa-grid-2" label={t.overview} />
          <SidebarLink view={AppView.BUDGET} activeView={activeView} setActiveView={setActiveView} icon="fa-chart-column" label={t.budget} />
          <SidebarLink view={AppView.PROJECTS} activeView={activeView} setActiveView={setActiveView} icon="fa-trowel-bricks" label={t.projects} />
          
          <div className="text-[10px] font-black text-slate-500 uppercase tracking-widest mt-8 mb-4 px-4">Accountability</div>
          <SidebarLink view={AppView.COMMITMENTS} activeView={activeView} setActiveView={setActiveView} icon="fa-handshake-simple" label={t.commitments} />
          <SidebarLink view={AppView.PARTICIPATION} activeView={activeView} setActiveView={setActiveView} icon="fa-users-rectangle" label={t.participation} />
          <SidebarLink view={AppView.LOGS} activeView={activeView} setActiveView={setActiveView} icon="fa-shield-check" label={t.logs} />
          
          <div className="text-[10px] font-black text-slate-500 uppercase tracking-widest mt-8 mb-4 px-4">Support</div>
          <SidebarLink view={AppView.ASSISTANT} activeView={activeView} setActiveView={setActiveView} icon="fa-wand-magic-sparkles" label={t.aiAssistant} />
        </nav>

        <div className="mt-8 pt-6 border-t border-slate-900/50">
          <div className="p-4 bg-slate-900/60 rounded-3xl border border-slate-800/50 backdrop-blur-sm group hover:border-slate-700 transition-all cursor-default">
             <div className="flex items-center gap-3 mb-4">
               <div className="relative">
                 <img src={profileImageUrl} className="w-10 h-10 rounded-2xl border border-slate-700 shadow-md transition-transform group-hover:scale-105" alt="User" />
                 <span className="absolute -bottom-1 -right-1 w-3.5 h-3.5 bg-emerald-500 border-2 border-slate-950 rounded-full"></span>
               </div>
               <div className="min-w-0">
                 <p className="text-xs font-black text-white truncate">{profile?.name}</p>
                 <p className="text-[10px] text-slate-500 font-bold truncate uppercase">{profile?.palika}</p>
               </div>
             </div>
             <button onClick={handleLogout} className="w-full py-2.5 bg-slate-800 hover:bg-rose-950/40 text-rose-400 hover:text-rose-300 text-[10px] font-black uppercase tracking-widest rounded-xl transition-all border border-transparent hover:border-rose-900/30">
               <i className="fa-solid fa-arrow-right-from-bracket mr-2"></i> {t.logout}
             </button>
          </div>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 md:ml-72 p-4 md:p-10 pb-28 md:pb-10 min-h-screen">
        <header className="mb-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-1">
            <h2 className="text-4xl font-black text-slate-900 tracking-tight flex items-center gap-3">
              {activeView === AppView.DASHBOARD && t.welcome}
              {activeView === AppView.BUDGET && t.budget}
              {activeView === AppView.PROJECTS && t.projects}
              {activeView === AppView.COMMITMENTS && t.commitments}
              {activeView === AppView.PARTICIPATION && t.participation}
              {activeView === AppView.LOGS && t.logs}
              {activeView === AppView.ASSISTANT && t.aiAssistant}
              <span className="hidden md:inline-block w-2 h-2 rounded-full bg-blue-600 animate-pulse"></span>
            </h2>
            <div className="flex items-center gap-2 text-slate-500 font-bold text-xs uppercase tracking-widest">
              <i className="fa-solid fa-location-dot text-blue-600"></i>
              <span>{profile?.palika} <span className="mx-1 opacity-30">/</span> {profile?.district} District</span>
            </div>
          </div>
          
          <div className="flex items-center gap-3 flex-wrap">
            <div className="flex items-center gap-1 bg-white p-1 rounded-2xl shadow-sm ring-1 ring-slate-100 overflow-x-auto no-scrollbar">
              {(['Nepali', 'English', 'Maithili', 'Bhojpuri'] as Language[]).map(lang => (
                <button
                  key={lang}
                  onClick={() => setLanguage(lang)}
                  className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase transition-all whitespace-nowrap ${
                    language === lang ? 'bg-slate-900 text-white shadow-lg' : 'text-slate-400 hover:text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  {lang}
                </button>
              ))}
            </div>

            <div className="relative group">
              <button className="w-11 h-11 rounded-2xl bg-white ring-1 ring-slate-100 flex items-center justify-center text-slate-400 hover:text-blue-600 hover:ring-blue-100 transition-all shadow-sm">
                <i className="fa-solid fa-bell-on"></i>
                {notifications.length > 0 && (
                  <span className="absolute top-2 right-2 w-2.5 h-2.5 bg-rose-500 border-2 border-white rounded-full"></span>
                )}
              </button>
              <div className="absolute right-0 mt-3 w-72 bg-white rounded-[2rem] shadow-2xl ring-1 ring-slate-100 hidden group-hover:block z-40 p-6 animate-in fade-in slide-in-from-top-2">
                 <div className="flex items-center justify-between mb-4">
                   <p className="text-[10px] font-black uppercase text-slate-400 tracking-widest">Recent Alerts</p>
                 </div>
                 <div className="space-y-4">
                   {notifications.map((n, i) => (
                     <div key={i} className="flex gap-3 text-xs group/item cursor-pointer">
                        <div className="w-1.5 h-1.5 rounded-full bg-blue-500 mt-1.5 shrink-0"></div>
                        <p className="text-slate-600 leading-snug group-hover/item:text-blue-600 transition-colors">{n}</p>
                     </div>
                   ))}
                 </div>
              </div>
            </div>
          </div>
        </header>

        <div className="max-w-7xl mx-auto space-y-10">
          {activeView === AppView.DASHBOARD && profile && <Dashboard projects={projects} budget={budget} language={language} profile={profile} />}
          {activeView === AppView.BUDGET && <BudgetOverview budget={budget} />}
          {activeView === AppView.PROJECTS && <ProjectTracker projects={projects} />}
          {activeView === AppView.COMMITMENTS && <CommitmentTracker language={language} />}
          {activeView === AppView.PARTICIPATION && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
              <div className="lg:col-span-12">
                <CivicPolls language={language} />
              </div>
              <div className="lg:col-span-12">
                <FeedbackHub feedbacks={feedbacks} setFeedbacks={setFeedbacks} language={language} />
              </div>
            </div>
          )}
          {activeView === AppView.LOGS && <TransparencyLog language={language} />}
          {activeView === AppView.ASSISTANT && <AICivicAssistant />}
        </div>
      </main>

      <nav className="md:hidden fixed bottom-6 left-6 right-6 bg-slate-900/90 backdrop-blur-xl border border-slate-800 px-4 flex justify-around items-center z-50 py-3 shadow-xl rounded-[2.5rem]">
        <NavItem view={AppView.DASHBOARD} icon="fa-house-user" activeView={activeView} setActiveView={setActiveView} />
        <NavItem view={AppView.BUDGET} icon="fa-chart-pie-simple" activeView={activeView} setActiveView={setActiveView} />
        <NavItem view={AppView.PROJECTS} icon="fa-road-barrier" activeView={activeView} setActiveView={setActiveView} />
        <NavItem view={AppView.PARTICIPATION} icon="fa-comments-question" activeView={activeView} setActiveView={setActiveView} />
        <NavItem view={AppView.ASSISTANT} icon="fa-sparkles" activeView={activeView} setActiveView={setActiveView} />
      </nav>
    </div>
  );
};

const SidebarLink: React.FC<{ view: AppView; activeView: AppView; setActiveView: (v: AppView) => void; icon: string; label: string }> = ({ view, activeView, setActiveView, icon, label }) => (
  <button
    onClick={() => setActiveView(view)}
    className={`w-full flex items-center gap-4 px-5 py-3.5 rounded-2xl transition-all duration-300 relative group ${
      activeView === view ? 'bg-blue-600 text-white shadow-xl shadow-blue-600/20' : 'text-slate-400 hover:text-slate-100 hover:bg-slate-900'
    }`}
  >
    <i className={`fa-solid ${icon} w-5 text-center text-sm ${activeView === view ? 'opacity-100' : 'opacity-60 group-hover:opacity-100'}`}></i>
    <span className="font-bold text-sm tracking-tight">{label}</span>
  </button>
);

const NavItem: React.FC<{ view: AppView; icon: string; activeView: AppView; setActiveView: (v: AppView) => void }> = ({ view, icon, activeView, setActiveView }) => (
  <button onClick={() => setActiveView(view)} className={`relative p-3 transition-all ${activeView === view ? 'text-blue-500' : 'text-slate-500'}`}>
    <i className={`fa-solid ${icon} text-xl`}></i>
  </button>
);

export default App;
