
import React, { useState } from 'react';
import { Project } from '../types';

interface ProjectTrackerProps {
  projects: Project[];
}

const ProjectTracker: React.FC<ProjectTrackerProps> = ({ projects }) => {
  const [filter, setFilter] = useState<string>('All');
  
  const filteredProjects = filter === 'All' 
    ? projects 
    : projects.filter(p => p.status === filter);

  return (
    <div className="space-y-6">
      <div className="flex overflow-x-auto gap-2 pb-2 scrollbar-hide">
        {['All', 'Planned', 'In Progress', 'Completed', 'Delayed'].map((s) => (
          <button
            key={s}
            onClick={() => setFilter(s)}
            className={`whitespace-nowrap px-6 py-2.5 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all ${
              filter === s ? 'bg-blue-600 text-white shadow-lg shadow-blue-900/20' : 'bg-white text-slate-500 border border-slate-200 hover:bg-slate-50'
            }`}
          >
            {s}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredProjects.map((project) => (
          <div key={project.id} className="bg-white rounded-[2rem] p-6 border border-slate-100 shadow-sm hover:shadow-xl transition-all group">
            <div className="flex justify-between items-start mb-6">
              <div className="bg-slate-900 text-white w-10 h-10 rounded-2xl flex items-center justify-center font-bold text-xs shadow-lg">
                W{project.ward || 'N'}
              </div>
              <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest ${
                project.status === 'Completed' ? 'bg-emerald-100 text-emerald-700' :
                project.status === 'Delayed' ? 'bg-red-100 text-red-700' :
                'bg-blue-100 text-blue-700'
              }`}>
                {project.status}
              </span>
            </div>
            
            <h4 className="text-xl font-black text-slate-800 mb-2 leading-tight group-hover:text-blue-600 transition-colors">{project.name}</h4>
            <p className="text-xs text-slate-500 mb-6 line-clamp-2">{project.description}</p>
            
            <div className="space-y-6 pt-6 border-t border-slate-50">
              <div>
                <div className="flex justify-between text-[10px] mb-2 font-black uppercase tracking-widest">
                  <span className="text-slate-400">Progress</span>
                  <span className="text-blue-600">{project.completionPercentage}%</span>
                </div>
                <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                  <div 
                    className={`h-full rounded-full transition-all duration-1000 ${project.status === 'Delayed' ? 'bg-red-500' : 'bg-blue-600'}`} 
                    style={{ width: `${project.completionPercentage}%` }}
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest mb-1">Spent / Budget</p>
                  <p className="font-bold text-slate-800 text-xs">NPR {(project.spent/1000000).toFixed(1)}M / {(project.budget/1000000).toFixed(1)}M</p>
                </div>
                <div className="text-right">
                  <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest mb-1">Update</p>
                  <p className="font-bold text-slate-800 text-xs">{project.lastUpdated}</p>
                </div>
              </div>

              <div className="flex gap-2">
                <button className="flex-1 py-3 bg-slate-900 text-white text-[10px] font-black uppercase tracking-widest rounded-xl hover:bg-blue-600 transition-colors">
                  View Docs
                </button>
                <button className="w-12 h-12 bg-slate-50 rounded-xl flex items-center justify-center text-slate-400 hover:text-orange-600 transition-colors">
                  <i className="fa-solid fa-camera"></i>
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ProjectTracker;
