
import React, { useState, useRef, useEffect } from 'react';
import { askCivicAssistant } from '../services/geminiService';

interface Message {
  role: 'user' | 'assistant';
  content: string;
  sources?: any[];
}

const AICivicAssistant: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([
    { role: 'assistant', content: "Namaste! I am your AI Civic Assistant. How can I help you today? You can ask me about local laws, budget allocation processes, or how to report a public issue." }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMsg = input.trim();
    setInput('');
    setMessages(prev => [...prev, { role: 'user', content: userMsg }]);
    setIsLoading(true);

    const result = await askCivicAssistant(userMsg);
    setMessages(prev => [...prev, { 
      role: 'assistant', 
      content: result.text || "I'm sorry, I couldn't process that.",
      sources: result.sources
    }]);
    setIsLoading(false);
  };

  return (
    <div className="max-w-4xl mx-auto h-[75vh] flex flex-col bg-white rounded-[3rem] shadow-[0_30px_100px_-20px_rgba(0,0,0,0.1)] border border-slate-100 overflow-hidden ring-1 ring-slate-100 animate-in zoom-in-95">
      {/* Header - Modern Glassy Blue */}
      <div className="bg-slate-950 p-6 text-white flex items-center justify-between border-b border-white/5">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-2xl flex items-center justify-center text-white text-2xl shadow-xl shadow-blue-500/20">
            <i className="fa-solid fa-sparkles"></i>
          </div>
          <div>
            <h3 className="text-xl font-black tracking-tight leading-none">Sushashan AI</h3>
            <p className="text-[10px] text-blue-400 font-bold uppercase tracking-[0.2em] mt-1.5 flex items-center gap-2">
               <span className="w-1.5 h-1.5 rounded-full bg-blue-400 animate-pulse"></span> Virtual Assistant
            </p>
          </div>
        </div>
        <div className="hidden sm:flex items-center gap-2 bg-white/5 px-4 py-2 rounded-full border border-white/10">
          <span className="text-[9px] font-black uppercase tracking-widest opacity-60">Status:</span>
          <span className="text-[9px] font-black uppercase tracking-widest text-emerald-400">Online</span>
        </div>
      </div>

      {/* Chat History Area */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto p-8 space-y-6 bg-slate-50/30 custom-scrollbar">
        {messages.map((msg, idx) => (
          <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[85%] p-6 rounded-[2rem] shadow-sm relative transition-all animate-in slide-in-from-bottom-2 duration-300 ${
              msg.role === 'user' 
                ? 'bg-slate-900 text-white rounded-tr-none' 
                : 'bg-white text-slate-800 border border-slate-100 rounded-tl-none ring-1 ring-slate-50'
            }`}>
              <p className="text-sm font-medium leading-relaxed whitespace-pre-line tracking-tight">{msg.content}</p>
              
              {msg.sources && msg.sources.length > 0 && (
                <div className="mt-6 pt-4 border-t border-slate-100/10">
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3">Linked Civic Resources:</p>
                  <div className="flex flex-wrap gap-2">
                    {msg.sources.map((chunk: any, i: number) => {
                      if (chunk.web) {
                        return (
                          <a 
                            key={i} 
                            href={chunk.web.uri} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="text-[10px] bg-slate-100/10 text-blue-400 px-3 py-2 rounded-xl border border-white/5 hover:bg-blue-600 hover:text-white transition-all font-black uppercase tracking-widest"
                          >
                            {chunk.web.title || 'Official Document'}
                          </a>
                        );
                      }
                      return null;
                    })}
                  </div>
                </div>
              )}
            </div>
          </div>
        ))}
        {isLoading && (
          <div className="flex justify-start">
            <div className="bg-white p-6 rounded-3xl rounded-tl-none border border-slate-100 shadow-sm flex items-center gap-2">
              <span className="w-1.5 h-1.5 bg-blue-500 rounded-full animate-bounce"></span>
              <span className="w-1.5 h-1.5 bg-blue-500 rounded-full animate-bounce delay-150"></span>
              <span className="w-1.5 h-1.5 bg-blue-500 rounded-full animate-bounce delay-300"></span>
            </div>
          </div>
        )}
      </div>

      {/* Input Area - Modern Bottom Bar */}
      <div className="p-8 bg-white border-t border-slate-50">
        <div className="max-w-3xl mx-auto relative group">
          <input 
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder="Ask about governance, local laws, or projects..."
            className="w-full pl-6 pr-24 py-5 rounded-[2rem] bg-slate-50 border-transparent border-2 focus:bg-white focus:border-blue-100 focus:ring-4 focus:ring-blue-50/50 outline-none transition-all font-medium text-slate-800 text-sm shadow-inner group-hover:shadow-md"
          />
          <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center gap-2">
            <button 
              onClick={handleSend}
              disabled={!input.trim() || isLoading}
              className="w-12 h-12 bg-slate-900 text-white rounded-[1.25rem] flex items-center justify-center hover:bg-blue-600 hover:shadow-xl hover:shadow-blue-500/20 disabled:opacity-20 transition-all active:scale-90"
            >
               <i className="fa-solid fa-paper-plane-top text-sm"></i>
            </button>
          </div>
        </div>
        <div className="flex justify-center gap-8 mt-6">
           {['Budget Tracking', 'Legal Queries', 'File Complaint'].map((tag) => (
             <button key={tag} onClick={() => setInput(tag)} className="text-[9px] font-black uppercase tracking-[0.2em] text-slate-400 hover:text-blue-600 transition-colors">
               # {tag}
             </button>
           ))}
        </div>
      </div>
    </div>
  );
};

export default AICivicAssistant;
