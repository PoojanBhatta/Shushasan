
import React, { useState } from 'react';
import { Feedback, Language } from '../types';
import { translations } from '../translations';
import { summarizeCitizenFeedback } from '../services/geminiService';

interface FeedbackHubProps {
  feedbacks: Feedback[];
  setFeedbacks: React.Dispatch<React.SetStateAction<Feedback[]>>;
  language: Language;
}

const FeedbackHub: React.FC<FeedbackHubProps> = ({ feedbacks, setFeedbacks, language }) => {
  const t = translations[language];
  const [formData, setFormData] = useState({
    name: '',
    type: 'Grievance',
    category: 'Infrastructure',
    subject: '',
    message: '',
    isAnonymous: false
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [summary, setSummary] = useState<string | null>(null);
  const [isSummarizing, setIsSummarizing] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    setTimeout(() => {
      const newFeedback: Feedback = {
        id: Math.random().toString(36).substr(2, 9),
        userName: formData.isAnonymous ? 'Anonymous Citizen' : (formData.name || 'Citizen'),
        type: formData.type as any,
        category: formData.category as any,
        subject: formData.subject,
        message: formData.message,
        timestamp: new Date().toISOString(),
        status: 'Submitted',
        isAnonymous: formData.isAnonymous
      };
      setFeedbacks([newFeedback, ...feedbacks]);
      setFormData({ name: '', type: 'Grievance', category: 'Infrastructure', subject: '', message: '', isAnonymous: false });
      setIsSubmitting(false);
      alert('Your grievance has been formally submitted. Tracking ID: ' + newFeedback.id);
    }, 1200);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
      <div className="lg:col-span-2 space-y-8">
        <div className="bg-white p-8 rounded-[2.5rem] shadow-sm border border-slate-100">
          <div className="mb-8">
            <h3 className="text-2xl font-black text-slate-800">{t.submitFeedback}</h3>
            <p className="text-sm text-slate-500 font-medium">Formal reporting for corruption, delays, or service issues.</p>
          </div>
          
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest pl-1">Full Name</label>
                <input 
                  type="text" disabled={formData.isAnonymous}
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  className="w-full px-5 py-3.5 rounded-2xl bg-slate-50 border-none focus:ring-2 focus:ring-blue-500 transition-all font-medium disabled:opacity-30" 
                  placeholder="Ram Bahadur" 
                />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest pl-1">Category</label>
                <select 
                   value={formData.category}
                   onChange={(e) => setFormData({...formData, category: e.target.value as any})}
                   className="w-full px-5 py-3.5 rounded-2xl bg-slate-50 border-none focus:ring-2 focus:ring-blue-500 font-bold text-slate-700 cursor-pointer"
                >
                  <option>Infrastructure</option><option>Corruption</option><option>Health</option><option>Sanitation</option><option>Education</option>
                </select>
              </div>
            </div>

            <div className="flex items-center gap-3 p-4 bg-orange-50 rounded-2xl border border-orange-100">
               <input 
                 type="checkbox" id="anon" 
                 checked={formData.isAnonymous}
                 onChange={(e) => setFormData({...formData, isAnonymous: e.target.checked})}
                 className="w-5 h-5 rounded text-orange-600 focus:ring-orange-500" 
               />
               <label htmlFor="anon" className="text-xs font-black text-orange-800 uppercase tracking-widest cursor-pointer">Submit Anonymously (For Whistleblowers)</label>
            </div>
            
            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest pl-1">Subject</label>
              <input 
                type="text" required
                value={formData.subject}
                onChange={(e) => setFormData({...formData, subject: e.target.value})}
                className="w-full px-5 py-3.5 rounded-2xl bg-slate-50 border-none focus:ring-2 focus:ring-blue-500 font-medium" 
                placeholder="Brief summary of the issue" 
              />
            </div>
            
            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest pl-1">Detailed Evidence / Message</label>
              <textarea 
                required rows={5}
                value={formData.message}
                onChange={(e) => setFormData({...formData, message: e.target.value})}
                className="w-full px-5 py-3.5 rounded-2xl bg-slate-50 border-none focus:ring-2 focus:ring-blue-500 font-medium resize-none" 
                placeholder="Include details, locations, and dates..."
              ></textarea>
            </div>
            
            <div className="flex items-center gap-4">
               <button className="px-6 py-4 bg-slate-100 text-slate-600 rounded-2xl text-xs font-black uppercase tracking-widest flex items-center gap-2 hover:bg-slate-200 transition-colors">
                  <i className="fa-solid fa-paperclip"></i> Attach Photos/Docs
               </button>
               <button 
                type="submit" disabled={isSubmitting}
                className="flex-1 py-5 bg-orange-600 hover:bg-orange-700 text-white rounded-2xl font-black shadow-xl shadow-orange-900/20 transition-all uppercase tracking-[0.2em] text-xs"
              >
                {isSubmitting ? 'Processing...' : 'Formal Submission'}
              </button>
            </div>
          </form>
        </div>

        <div className="space-y-4">
          <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] px-2">Recent Grievance Statuses</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {feedbacks.map((f) => (
              <div key={f.id} className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm">
                <div className="flex justify-between items-start mb-4">
                  <span className={`px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-widest ${
                    f.status === 'Action Taken' ? 'bg-emerald-100 text-emerald-700' : 'bg-blue-100 text-blue-700'
                  }`}>
                    {f.status}
                  </span>
                  <span className="text-[10px] text-slate-400 font-bold">ID: {f.id}</span>
                </div>
                <h6 className="text-sm font-black text-slate-800 mb-1">{f.subject}</h6>
                <p className="text-[10px] text-slate-400 font-bold uppercase mb-2">{f.category} • {f.userName}</p>
                <div className="w-full h-1 bg-slate-100 rounded-full mt-4 overflow-hidden">
                   <div className={`h-full bg-blue-500 ${f.status === 'Submitted' ? 'w-1/4' : f.status === 'Reviewed' ? 'w-2/4' : 'w-full'}`}></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="space-y-6">
        <div className="bg-slate-900 text-white p-8 rounded-[2.5rem] shadow-2xl relative overflow-hidden">
          <h3 className="text-xl font-black mb-6 relative z-10 leading-tight">Civic Protection</h3>
          <ul className="space-y-6 relative z-10">
            {[
              {icon: 'fa-user-shield', text: 'Encrypted anonymous reporting for safety.', color: 'text-orange-400'},
              {icon: 'fa-list-check', text: 'Formal tracking of every official response.', color: 'text-blue-400'}
            ].map((item, i) => (
              <li key={i} className="flex gap-4 items-start">
                <div className={`w-10 h-10 rounded-2xl bg-white/5 flex items-center justify-center shrink-0 ${item.color} border border-white/5 shadow-inner`}>
                  <i className={`fa-solid ${item.icon}`}></i>
                </div>
                <span className="text-slate-300 text-sm font-medium leading-snug">{item.text}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
};

export default FeedbackHub;
