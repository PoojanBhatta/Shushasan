
import React from 'react';
import { Project, BudgetEntry, NewsItem, Language, UserProfile } from '../types';
import { translations } from '../translations';
import { MOCK_NEWS } from '../constants';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

interface DashboardProps {
  projects: Project[];
  budget: BudgetEntry[];
  language: Language;
  profile: UserProfile;
}

const Dashboard: React.FC<DashboardProps> = ({ projects, budget, language, profile }) => {
  const t = translations[language];
  const totalBudget = budget.reduce((acc, curr) => acc + curr.allocated, 0);
  const totalSpent = budget.reduce((acc, curr) => acc + curr.spent, 0);
  const remaining = totalBudget - totalSpent;

  const budgetData = budget.map(b => ({
    name: b.category,
    allocated: b.allocated / 1000000,
    spent: b.spent / 1000000
  }));

  const prideProjects = projects.filter(p => p.isNationalPride);
  const profileImageUrl = `https://api.dicebear.com/7.x/avataaars/svg?seed=RamBahadurThapa&backgroundColor=b6e3f4&style=circle`;

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
      {/* LEFT COLUMN: Main Highlights */}
      <div className="lg:col-span-8 space-y-10">
        
        {/* Welcome Card - Dynamic Accent */}
        <section className="bg-gradient-to-br from-blue-600 to-indigo-700 p-8 rounded-[2.5rem] shadow-xl text-white flex flex-col sm:flex-row items-center gap-6 relative overflow-hidden">
           <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full -mr-20 -mt-20 blur-3xl"></div>
           <img src={profileImageUrl} className="w-24 h-24 rounded-3xl border-4 border-white/20 shadow-2xl relative z-10" alt="Avatar" />
           <div className="relative z-10 text-center sm:text-left">
             <h2 className="text-3xl font-black tracking-tight mb-2">नमस्ते, {profile.name}</h2>
             <p className="text-blue-100 font-medium opacity-80">तपाईको क्षेत्र: {profile.palika}, {profile.district}</p>
             <p className="text-[10px] font-black uppercase tracking-widest mt-4 text-white bg-white/20 inline-block px-3 py-1 rounded-full">आधिकारिक नागरिक प्रोफाइल</p>
           </div>
        </section>

        {/* Transparency Tracker - Bento Style */}
        <section className="bg-white rounded-[2.5rem] shadow-sm border border-slate-100 overflow-hidden ring-1 ring-slate-100">
          <div className="p-8 border-b border-slate-50 flex justify-between items-center bg-gradient-to-r from-blue-50/20 to-transparent">
            <h3 className="font-black text-slate-900 flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-slate-900 text-white flex items-center justify-center text-sm shadow-xl">
                <i className="fa-solid fa-chart-line-up"></i>
              </div>
              <span className="text-xl tracking-tight">{t.transparency}</span>
            </h3>
            <div className="flex items-center gap-2">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
              </span>
              <span className="text-[10px] text-slate-400 font-black uppercase tracking-widest">Live Updates</span>
            </div>
          </div>
          
          <div className="p-8">
             <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 mb-10">
               <div className="group p-6 bg-slate-50 rounded-3xl border border-slate-100 hover:bg-white hover:shadow-xl transition-all duration-500">
                 <p className="text-[10px] text-slate-400 uppercase font-black tracking-[0.2em] mb-3">{t.spendingRate}</p>
                 <div className="flex items-end justify-between">
                   <h4 className="text-4xl font-black text-slate-900 tracking-tighter">
                     {((totalSpent/totalBudget)*100).toFixed(1)}<span className="text-xl ml-0.5 text-blue-600">%</span>
                   </h4>
                   <div className="w-12 h-12 rounded-full bg-emerald-50 flex items-center justify-center text-emerald-600">
                     <i className="fa-solid fa-arrow-up-right"></i>
                   </div>
                 </div>
                 <div className="w-full h-2 bg-slate-200 rounded-full mt-6 overflow-hidden">
                   <div className="h-full bg-gradient-to-r from-blue-600 to-indigo-600 rounded-full group-hover:scale-x-105 origin-left transition-transform duration-700" style={{width: `${(totalSpent/totalBudget)*100}%`}}></div>
                 </div>
               </div>
               
               <div className="group p-6 bg-slate-50 rounded-3xl border border-slate-100 hover:bg-white hover:shadow-xl transition-all duration-500">
                 <p className="text-[10px] text-slate-400 uppercase font-black tracking-[0.2em] mb-3">{t.remaining}</p>
                 <div className="flex items-end justify-between">
                   <h4 className="text-4xl font-black text-slate-900 tracking-tighter">
                     <span className="text-lg mr-1 text-emerald-500 font-bold">NPR</span>{(remaining/1000000).toFixed(1)}<span className="text-xl ml-0.5 opacity-40">M</span>
                   </h4>
                   <div className="w-12 h-12 rounded-full bg-orange-50 flex items-center justify-center text-orange-600">
                     <i className="fa-solid fa-coins"></i>
                   </div>
                 </div>
                 <p className="text-[10px] text-slate-400 font-bold mt-4 uppercase tracking-widest">Total: {(totalBudget/1000000).toFixed(0)}M Allocated</p>
               </div>
             </div>

             <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={budgetData.slice(0, 4)}>
                  <CartesianGrid strokeDasharray="6 6" vertical={false} stroke="#f1f5f9" />
                  <XAxis 
                    dataKey="name" 
                    fontSize={10} 
                    fontWeight={900} 
                    axisLine={false} 
                    tickLine={false} 
                    tick={{fill: '#94a3b8'}}
                    dy={10}
                  />
                  <Tooltip 
                    cursor={{fill: 'rgba(241, 245, 249, 0.5)'}} 
                    contentStyle={{borderRadius: '24px', border: 'none', boxShadow: '0 25px 50px -12px rgba(0,0,0,0.15)', padding: '16px'}} 
                  />
                  <Bar dataKey="spent" fill="#2563eb" radius={[12, 12, 12, 12]} barSize={48} />
                </BarChart>
              </ResponsiveContainer>
             </div>
          </div>
        </section>

        {/* Local News Feed */}
        <section className="space-y-6">
          <div className="flex items-center justify-between px-4">
            <h3 className="font-black text-slate-900 uppercase text-xs tracking-[0.2em]">{t.localNews}</h3>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            {MOCK_NEWS.map(news => (
              <article key={news.id} className="group bg-white rounded-[2.5rem] shadow-sm border border-slate-100 p-8 hover:shadow-2xl hover:-translate-y-1 transition-all duration-500 flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-3 mb-6">
                    <div className="w-12 h-12 rounded-[1.25rem] bg-orange-50 text-orange-600 flex items-center justify-center text-xl shrink-0 group-hover:scale-110 transition-transform duration-500">
                      <i className="fa-solid fa-megaphone"></i>
                    </div>
                    <div>
                      <h4 className="font-black text-slate-800 text-lg leading-none mb-1.5">{news.title}</h4>
                      <div className="flex items-center gap-2">
                        <span className="text-[9px] text-blue-600 font-black uppercase tracking-tighter bg-blue-50 px-2 py-0.5 rounded-md">{news.location}</span>
                        <span className="text-[9px] text-slate-400 font-black tracking-widest uppercase">{news.date}</span>
                      </div>
                    </div>
                  </div>
                  <p className="text-slate-500 leading-relaxed text-sm mb-8 line-clamp-3">{news.content}</p>
                </div>
              </article>
            ))}
          </div>
        </section>
      </div>

      {/* RIGHT COLUMN */}
      <div className="lg:col-span-4 space-y-10">
        <section className="space-y-6">
          <div className="flex items-center gap-2 px-2">
            <div className="w-1.5 h-6 bg-blue-600 rounded-full"></div>
            <h3 className="font-black text-slate-900 uppercase text-xs tracking-[0.2em]">{t.nationalPride}</h3>
          </div>
          
          <div className="space-y-8">
            {prideProjects.map(project => (
              <div key={project.id} className="bg-white rounded-[2.5rem] shadow-sm border border-slate-100 overflow-hidden group hover:shadow-2xl transition-all duration-700">
                 {project.videoUrl && (
                   <div className="aspect-[4/3] bg-slate-900 relative overflow-hidden cursor-pointer">
                      <img src={`https://picsum.photos/seed/${project.id}v/800/600`} alt="Project Progress" className="w-full h-full object-cover opacity-60 group-hover:scale-110 transition-transform duration-1000 ease-out" />
                      <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/20 to-transparent"></div>
                      <div className="absolute inset-0 flex items-center justify-center">
                        <div className="w-16 h-16 bg-white/10 backdrop-blur-xl text-white rounded-full flex items-center justify-center shadow-2xl ring-1 ring-white/20 group-hover:scale-110 transition-transform duration-500">
                          <i className="fa-solid fa-play text-xl ml-1"></i>
                        </div>
                      </div>
                      <div className="absolute bottom-6 left-6 right-6 text-white">
                        <h5 className="font-black text-lg leading-tight mb-1 group-hover:text-blue-400 transition-colors">{project.name}</h5>
                        <p className="text-white/60 text-[10px] font-bold uppercase tracking-widest">Progress: {project.completionPercentage}%</p>
                      </div>
                   </div>
                 )}
                 <div className="p-8">
                    <div className="space-y-4">
                      <div className="w-full h-3 bg-slate-50 rounded-full overflow-hidden shadow-inner ring-1 ring-slate-100">
                        <div className="h-full bg-gradient-to-r from-blue-600 to-indigo-600 rounded-full transition-all duration-1000 ease-in-out group-hover:opacity-80" style={{width: `${project.completionPercentage}%`}}></div>
                      </div>
                      <button className="w-full mt-4 py-4 bg-slate-50 group-hover:bg-slate-900 group-hover:text-white rounded-2xl text-[10px] font-black uppercase tracking-[0.2em] transition-all duration-300">
                        View Full Project Ledger
                      </button>
                    </div>
                 </div>
              </div>
            ))}
          </div>
        </section>

        <section className="bg-gradient-to-br from-slate-900 to-slate-950 p-8 rounded-[2.5rem] shadow-2xl relative overflow-hidden text-white">
           <div className="absolute -top-10 -right-10 w-40 h-40 bg-blue-600/20 rounded-full blur-3xl"></div>
           <div className="relative z-10">
              <h4 className="text-lg font-black mb-6 flex items-center gap-3 tracking-tight">
                 <i className="fa-solid fa-shield-halved text-blue-400"></i> Accountability Score
              </h4>
              <div className="space-y-6">
                <div className="flex items-center justify-between p-4 bg-white/5 rounded-2xl border border-white/5">
                   <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">Audit Status</span>
                   <span className="text-[10px] font-black text-emerald-400 uppercase tracking-widest bg-emerald-400/10 px-3 py-1 rounded-full">Passed</span>
                </div>
              </div>
              <p className="mt-8 text-[10px] text-slate-500 font-bold leading-relaxed text-center uppercase tracking-widest italic">
                Data verified by the Auditor General
              </p>
           </div>
        </section>
      </div>
    </div>
  );
};

export default Dashboard;
