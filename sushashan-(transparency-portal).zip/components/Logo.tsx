
import React from 'react';

interface LogoProps {
  className?: string;
}

const Logo: React.FC<LogoProps> = ({ className = "w-12 h-12" }) => {
  return (
    <svg 
      viewBox="0 0 400 400" 
      fill="none" 
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-label="Sushashan Logo"
    >
      {/* Outer Circular Frame - Navy Blue */}
      <path 
        d="M170 130C125 145 95 188 95 238C95 296 142 343 200 343C258 343 305 296 305 238C305 188 275 145 230 130" 
        stroke="#2D4B73" 
        strokeWidth="12" 
        strokeLinecap="round" 
      />

      {/* Inner Accent Arcs - Gold/Orange */}
      <path 
        d="M115 210C108 235 110 275 130 305" 
        stroke="#D4A056" 
        strokeWidth="4" 
        strokeLinecap="round" 
        opacity="0.8"
      />
      <path 
        d="M285 210C292 235 290 275 270 305" 
        stroke="#D4A056" 
        strokeWidth="4" 
        strokeLinecap="round" 
        opacity="0.8"
      />

      {/* Person Silhouette - Navy Blue */}
      {/* Head */}
      <path 
        d="M200 165C183 165 170 178 170 195C170 212 183 225 200 225C217 225 230 212 230 195C230 178 217 165 200 165Z" 
        stroke="#2D4B73" 
        strokeWidth="10" 
        fill="white"
      />
      {/* Hair Detail */}
      <path 
        d="M170 195C170 175 185 170 200 170C215 170 230 180 230 195" 
        stroke="#2D4B73" 
        strokeWidth="10" 
        strokeLinecap="round"
      />
      {/* Shoulders/Body */}
      <path 
        d="M150 270C150 245 170 235 200 235C230 235 250 245 250 270V300H150V270Z" 
        stroke="#2D4B73" 
        strokeWidth="10" 
        strokeLinecap="round" 
        fill="white"
      />
      {/* Collar detail */}
      <path d="M190 235L200 245L210 235" stroke="#2D4B73" strokeWidth="6" strokeLinecap="round" strokeLinejoin="round" />
      {/* Shirt pocket/detail */}
      <path d="M175 275V290" stroke="#2D4B73" strokeWidth="6" strokeLinecap="round" />
      <path d="M225 275V290" stroke="#2D4B73" strokeWidth="6" strokeLinecap="round" />

      {/* Speech Bubble - Gold/Orange */}
      <g>
        <path 
          d="M210 175C210 155 230 140 255 140C280 140 300 155 300 175C300 190 290 203 275 208L280 222L255 210H250C228 210 210 195 210 175Z" 
          stroke="#D4A056" 
          strokeWidth="10" 
          strokeLinecap="round" 
          strokeLinejoin="round"
          fill="white"
        />
        {/* Three Dots */}
        <circle cx="235" cy="175" r="4" fill="#D4A056" />
        <circle cx="255" cy="175" r="4" fill="#D4A056" />
        <circle cx="275" cy="175" r="4" fill="#D4A056" />
      </g>
    </svg>
  );
};

export default Logo;
