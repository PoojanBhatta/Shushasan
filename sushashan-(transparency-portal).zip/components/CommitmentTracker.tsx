
import React from 'react';
import { MOCK_COMMITMENTS } from '../constants';
import { Language } from '../types';
import { translations } from '../translations';

const CommitmentTracker: React.FC<{ language: Language }> = ({ language }) => {
  const t = translations[language];
  
  return (
    <div className="space-y-8 max-w-4xl mx-auto">
      <div className="bg-orange-600 text-white p-10 rounded-[2.5rem] shadow-2xl relative overflow-hidden">
        <i className="fa-solid fa-bullhorn absolute -right-10 -bottom-10 text-[15rem] opacity-10 rotate-12"></i>
        <div className="relative z-10">
          <h3 className="text-3xl font-black mb-4">{t.officialPromises}</h3>
          <p className="text-orange-100 max-w-xl font-medium">Tracking verbal and written commitments made by your representatives to ensure they translate into action.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {MOCK_COMMITMENTS.map((c) => (
          <div key={c.id} className="bg-white p-8 rounded-[2rem] border border-slate-100 shadow-sm relative overflow-hidden group hover:shadow-xl transition-all">
            <div className={`absolute top-0 right-0 w-24 h-24 blur-2xl opacity-10 rounded-full -mr-8 -mt-8 ${
              c.status === 'Fulfilled' ? 'bg-emerald-500' : 'bg-orange-500'
            }`}></div>
            
            <div className="flex items-center gap-4 mb-6">
              <img src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${c.officialName}`} className="w-12 h-12 rounded-2xl bg-slate-50 border border-slate-100 shadow-sm" alt="Official" />
              <div>
                <h4 className="font-black text-slate-800 leading-tight">{c.officialName}</h4>
                <p className="text-[10px] text-blue-600 font-black uppercase tracking-widest">{c.position}</p>
              </div>
            </div>

            <p className="text-slate-600 font-bold italic mb-8 border-l-4 border-orange-500 pl-4">"{c.promise}"</p>

            <div className="flex justify-between items-center pt-6 border-t border-slate-50">
              <div>
                <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest mb-1">Target Date</p>
                <p className="text-sm font-black text-slate-800">{c.deadline}</p>
              </div>
              <span className={`px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest ${
                c.status === 'Fulfilled' ? 'bg-emerald-100 text-emerald-700' :
                c.status === 'Pending' ? 'bg-slate-100 text-slate-600' :
                'bg-orange-100 text-orange-700'
              }`}>
                {c.status}
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CommitmentTracker;
