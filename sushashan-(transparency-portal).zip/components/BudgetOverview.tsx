
import React from 'react';
import { BudgetEntry } from '../types';

interface BudgetOverviewProps {
  budget: BudgetEntry[];
}

const BudgetOverview: React.FC<BudgetOverviewProps> = ({ budget }) => {
  return (
    <div className="space-y-10">
      {/* Visual Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {[
          { label: 'Total Budget', val: 'NPR 115M', icon: 'fa-vault', color: 'bg-blue-600', text: 'text-white' },
          { label: 'Public Assets', val: '42 Active', icon: 'fa-building-columns', color: 'bg-white', text: 'text-slate-900' },
          { label: 'Fiscal Health', val: 'Excellent', icon: 'fa-heart-pulse', color: 'bg-white', text: 'text-slate-900' }
        ].map((stat, i) => (
          <div key={i} className={`${stat.color} ${stat.text} p-8 rounded-[2.5rem] shadow-sm ring-1 ring-slate-100 flex items-center justify-between group hover:shadow-2xl hover:-translate-y-1 transition-all duration-500`}>
             <div>
               <p className="text-[10px] font-black uppercase tracking-[0.2em] mb-2 opacity-60">{stat.label}</p>
               <h4 className="text-3xl font-black tracking-tighter leading-none">{stat.val}</h4>
             </div>
             <div className={`w-14 h-14 rounded-2xl ${stat.color === 'bg-white' ? 'bg-slate-50 text-slate-400' : 'bg-white/20 text-white'} flex items-center justify-center text-xl shadow-inner group-hover:scale-110 transition-transform`}>
               <i className={`fa-solid ${stat.icon}`}></i>
             </div>
          </div>
        ))}
      </div>

      {/* Main Budget Data View */}
      <div className="bg-white rounded-[2.5rem] shadow-[0_20px_50px_rgba(0,0,0,0.04)] border border-slate-100 overflow-hidden ring-1 ring-slate-100">
        <div className="p-10 border-b border-slate-50 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div>
            <h3 className="text-2xl font-black text-slate-900 tracking-tight">Financial Disclosure</h3>
            <p className="text-sm text-slate-500 font-medium mt-1">Real-time tracking of public fund circulation across wards.</p>
          </div>
          <div className="flex gap-2">
            <button className="px-6 py-3 bg-slate-900 text-white text-[10px] font-black uppercase tracking-widest rounded-2xl hover:bg-slate-800 transition-all shadow-lg shadow-slate-900/10">
              <i className="fa-solid fa-file-export mr-2"></i> Export CSV
            </button>
            <button className="px-6 py-3 bg-slate-100 text-slate-600 text-[10px] font-black uppercase tracking-widest rounded-2xl hover:bg-slate-200 transition-all">
              <i className="fa-solid fa-filter mr-2"></i> Filters
            </button>
          </div>
        </div>
        
        <div className="overflow-x-auto no-scrollbar">
          <table className="w-full text-left border-collapse">
            <thead className="bg-slate-50/50">
              <tr>
                <th className="px-10 py-5 text-[10px] font-black text-slate-400 uppercase tracking-widest">Department Category</th>
                <th className="px-10 py-5 text-[10px] font-black text-slate-400 uppercase tracking-widest text-right">Allocation (NPR)</th>
                <th className="px-10 py-5 text-[10px] font-black text-slate-400 uppercase tracking-widest text-right">Current Spend</th>
                <th className="px-10 py-5 text-[10px] font-black text-slate-400 uppercase tracking-widest text-right">Efficiency</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {budget.map((item) => {
                const percentage = (item.spent / item.allocated) * 100;
                return (
                  <tr key={item.id} className="group hover:bg-blue-50/30 transition-all">
                    <td className="px-10 py-8">
                      <div className="font-black text-slate-900 text-lg tracking-tight mb-1">{item.category}</div>
                      <div className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">{item.description}</div>
                    </td>
                    <td className="px-10 py-8 text-right font-black text-slate-700 text-lg tabular-nums">
                      {item.allocated.toLocaleString()}
                    </td>
                    <td className="px-10 py-8 text-right font-black text-blue-600 text-lg tabular-nums">
                      {item.spent.toLocaleString()}
                    </td>
                    <td className="px-10 py-8 text-right">
                      <div className="flex flex-col items-end">
                        <div className="flex items-center gap-2 mb-3">
                           <span className={`text-[11px] font-black tracking-tighter ${percentage > 90 ? 'text-orange-600' : 'text-emerald-600'}`}>
                             {percentage.toFixed(1)}%
                           </span>
                        </div>
                        <div className="w-32 h-2 bg-slate-100 rounded-full overflow-hidden shadow-inner ring-1 ring-slate-100">
                          <div 
                            className={`h-full rounded-full transition-all duration-1000 ${
                              percentage > 90 ? 'bg-orange-500' : 'bg-emerald-500'
                            }`}
                            style={{ width: `${Math.min(percentage, 100)}%` }}
                          />
                        </div>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-emerald-600 p-12 rounded-[3rem] text-white relative overflow-hidden group hover:shadow-2xl transition-all duration-500">
           <i className="fa-solid fa-file-invoice-dollar absolute -right-8 -bottom-8 text-[12rem] opacity-10 group-hover:scale-110 transition-transform duration-700"></i>
           <div className="relative z-10 max-w-md">
             <span className="text-[10px] font-black uppercase tracking-[0.3em] opacity-80 mb-4 block">Official Documents</span>
             <h4 className="text-3xl font-black mb-4 tracking-tight leading-none">Public Audit Reports</h4>
             <p className="text-emerald-100 text-sm font-medium mb-10 leading-relaxed opacity-80">Download verified quarterly audit reports validated by the Supreme Court of Audit to ensure zero-corruption benchmarks.</p>
             <button className="bg-white text-emerald-600 px-10 py-4 rounded-2xl font-black text-xs uppercase tracking-widest hover:shadow-xl hover:scale-105 transition-all active:scale-95">
               Download Last Report <i className="fa-solid fa-cloud-arrow-down ml-2"></i>
             </button>
           </div>
        </div>
        
        <div className="bg-slate-900 p-12 rounded-[3rem] text-white relative overflow-hidden group hover:shadow-2xl transition-all duration-500">
           <i className="fa-solid fa-handshake-angle absolute -right-8 -bottom-8 text-[12rem] opacity-10 group-hover:scale-110 transition-transform duration-700"></i>
           <div className="relative z-10 max-w-md">
             <span className="text-[10px] font-black uppercase tracking-[0.3em] opacity-80 mb-4 block">Community Action</span>
             <h4 className="text-3xl font-black mb-4 tracking-tight leading-none">Propose Development</h4>
             <p className="text-slate-400 text-sm font-medium mb-10 leading-relaxed opacity-80">Are you a community lead? Submit funding proposals for local sanitation, educational resources, or solar grid implementations.</p>
             <button className="bg-blue-600 text-white px-10 py-4 rounded-2xl font-black text-xs uppercase tracking-widest hover:shadow-xl hover:bg-blue-500 hover:scale-105 transition-all active:scale-95">
               Submit Funding Request <i className="fa-solid fa-circle-plus ml-2"></i>
             </button>
           </div>
        </div>
      </div>
    </div>
  );
};

export default BudgetOverview;
