
import React, { useState } from 'react';
import { MOCK_POLLS } from '../constants';
import { Language } from '../types';
import { translations } from '../translations';

const CivicPolls: React.FC<{ language: Language }> = ({ language }) => {
  const t = translations[language];
  const [voted, setVoted] = useState<string | null>(null);

  return (
    <div className="space-y-6">
      <h3 className="font-black text-slate-400 uppercase text-[10px] tracking-[0.2em] px-2">{t.polls}</h3>
      {MOCK_POLLS.map((poll) => (
        <div key={poll.id} className="bg-white p-8 rounded-[2.5rem] shadow-sm border border-slate-100">
          <div className="flex items-center gap-4 mb-8">
            <div className="w-12 h-12 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center text-xl shadow-inner">
              <i className="fa-solid fa-square-poll-vertical"></i>
            </div>
            <div>
              <h4 className="text-xl font-black text-slate-800 leading-tight">{poll.question}</h4>
              <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Ending: {poll.endDate}</p>
            </div>
          </div>

          <div className="space-y-4">
            {poll.options.map((opt, i) => {
              const percentage = (opt.votes / poll.totalVotes) * 100;
              return (
                <button 
                  key={i} 
                  disabled={!!voted}
                  onClick={() => setVoted(opt.text)}
                  className={`w-full text-left relative overflow-hidden p-5 rounded-2xl border transition-all ${
                    voted === opt.text ? 'border-indigo-500 ring-2 ring-indigo-100' : 'border-slate-100 hover:bg-slate-50'
                  }`}
                >
                  <div 
                    className={`absolute inset-0 bg-indigo-50 transition-all duration-1000 ${voted ? 'opacity-100' : 'opacity-0'}`} 
                    style={{ width: voted ? `${percentage}%` : '0%' }}
                  ></div>
                  <div className="relative flex justify-between items-center font-bold text-sm">
                    <span className={voted === opt.text ? 'text-indigo-800' : 'text-slate-700'}>{opt.text}</span>
                    {voted && <span className="text-indigo-600">{percentage.toFixed(1)}%</span>}
                  </div>
                </button>
              );
            })}
          </div>
          
          <div className="mt-8 flex justify-between items-center text-[10px] font-black uppercase text-slate-400">
             <span>{poll.totalVotes.toLocaleString()} Votes Recorded</span>
             {voted && <span className="text-indigo-500">Thank you for voting!</span>}
          </div>
        </div>
      ))}
    </div>
  );
};

export default CivicPolls;
