
import { UserProfile } from '../types';
import React, { useState, useRef, useEffect } from 'react';
import Logo from './Logo';

interface LoginPortalProps {
  onLogin: (profile: UserProfile) => void;
}

const Container: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <div className="min-h-screen flex items-center justify-center bg-slate-50 p-6 selection:bg-orange-100 font-sans">
    <div className="max-w-md w-full bg-white rounded-[3rem] shadow-[0_50px_100px_-20px_rgba(0,0,0,0.1)] border border-slate-100 overflow-hidden ring-1 ring-slate-100/50">
      {children}
    </div>
  </div>
);

const Header = ({ title, subtitle }: { title: string, subtitle: string }) => (
  <div className="bg-slate-950 p-12 text-white text-center relative overflow-hidden">
    <div className="absolute top-0 right-0 w-48 h-48 bg-blue-600/20 rounded-full blur-[80px] -mr-24 -mt-24 animate-pulse"></div>
    <div className="absolute bottom-0 left-0 w-32 h-32 bg-indigo-600/10 rounded-full blur-[60px] -ml-16 -mb-16"></div>
    
    <div className="w-32 h-32 bg-white rounded-[2.5rem] flex items-center justify-center mx-auto mb-8 shadow-2xl transform transition-transform hover:scale-105 duration-500">
      <Logo className="w-24 h-24" />
    </div>
    <h1 className="text-4xl font-black tracking-tighter leading-none mb-2">{title}</h1>
    <p className="text-blue-400 text-[10px] font-black uppercase tracking-[0.3em] opacity-80">{subtitle}</p>
  </div>
);

const LoginPortal: React.FC<LoginPortalProps> = ({ onLogin }) => {
  const [step, setStep] = useState<'details' | 'otp' | 'location'>('details');
  const [loading, setLoading] = useState(false);
  const [dateError, setDateError] = useState('');
  const [locationLoading, setLocationLoading] = useState(false);
  
  const [formData, setFormData] = useState({
    name: 'Ram Bahadur Thapa',
    mobile: '',
    citizenship: '',
    dob: '', 
    district: '',
    palika: ''
  });
  
  const [otp, setOtp] = useState(['', '', '', '', '', '']);
  const otpInputs = useRef<(HTMLInputElement | null)[]>([]);

  const profileImageUrl = `https://api.dicebear.com/7.x/avataaars/svg?seed=RamBahadurThapa&backgroundColor=b6e3f4&style=circle`;

  const validateDateBS = (val: string) => {
    const regex = /^(\d{1,2})-(\d{1,2})-(\d{4})$/;
    if (!regex.test(val)) return false;
    
    const [_, d, m, y] = val.match(regex) || [];
    const day = parseInt(d);
    const month = parseInt(m);
    const year = parseInt(y);

    if (month < 1 || month > 12) return false;
    if (day < 1 || day > 32) return false;
    if (year < 2000 || year > 2100) return false;
    
    return true;
  };

  const handleDetailsSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateDateBS(formData.dob)) {
      setDateError("Please use valid BS format (DD-MM-YYYY)");
      return;
    }
    setDateError('');
    setLoading(true);
    setTimeout(() => {
      setStep('otp');
      setLoading(false);
    }, 1500);
  };

  const handleOtpChange = (index: number, value: string) => {
    if (isNaN(Number(value))) return;
    const newOtp = [...otp];
    newOtp[index] = value.substring(value.length - 1);
    setOtp(newOtp);

    if (value && index < 5) {
      otpInputs.current[index + 1]?.focus();
    }
  };

  const handleOtpKeyDown = (index: number, e: React.KeyboardEvent) => {
    if (e.key === 'Backspace' && !otp[index] && index > 0) {
      otpInputs.current[index - 1]?.focus();
    }
  };

  const handleOtpSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setTimeout(() => {
      setStep('location');
      setLoading(false);
    }, 1200);
  };

  const handleDetectLocation = () => {
    if (!navigator.geolocation) {
      alert("Geolocation is not supported by your browser");
      return;
    }

    setLocationLoading(true);
    navigator.geolocation.getCurrentPosition(
      (position) => {
        setTimeout(() => {
          setFormData({
            ...formData,
            district: 'Kathmandu',
            palika: 'Kathmandu Metropolitan'
          });
          setLocationLoading(false);
        }, 1500);
      },
      (error) => {
        console.error(error);
        alert("Permission denied or location unavailable.");
        setLocationLoading(false);
      }
    );
  };

  const handleLocationSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onLogin(formData as UserProfile);
  };

  if (step === 'details') {
    return (
      <Container>
        <Header title="सुशासन" subtitle="National Citizen Gateway" />
        <form onSubmit={handleDetailsSubmit} className="p-12 space-y-6">
          <div className="space-y-3">
            <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] ml-1">Mobile Access</label>
            <input 
              type="tel" required placeholder="98XXXXXXXX"
              value={formData.mobile} onChange={e => setFormData({...formData, mobile: e.target.value})}
              className="w-full px-6 py-5 rounded-3xl bg-slate-50 border-none focus:ring-4 focus:ring-blue-50/50 outline-none font-black text-slate-800 transition-all placeholder:text-slate-300 shadow-inner"
            />
          </div>
          <div className="space-y-3">
            <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] ml-1">Citizenship ID</label>
            <input 
              type="text" required placeholder="XX-XX-XX-XXXXX"
              value={formData.citizenship} onChange={e => setFormData({...formData, citizenship: e.target.value})}
              className="w-full px-6 py-5 rounded-3xl bg-slate-50 border-none focus:ring-4 focus:ring-blue-50/50 outline-none font-black text-slate-800 transition-all placeholder:text-slate-300 shadow-inner"
            />
          </div>
          <div className="space-y-3">
            <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] ml-1">Birth Date (BS: DD-MM-YYYY)</label>
            <input 
              type="text" required placeholder="DD-MM-YYYY"
              value={formData.dob} onChange={e => setFormData({...formData, dob: e.target.value})}
              className={`w-full px-6 py-5 rounded-3xl bg-slate-50 border-2 outline-none font-black text-slate-800 transition-all placeholder:text-slate-300 shadow-inner ${dateError ? 'border-rose-400 focus:ring-rose-50' : 'border-transparent focus:ring-blue-50/50'}`}
            />
            {dateError && <p className="text-[10px] font-bold text-rose-500 ml-2">{dateError}</p>}
          </div>
          <button type="submit" disabled={loading} className="w-full py-6 bg-slate-900 hover:bg-slate-800 text-white rounded-3xl font-black uppercase tracking-[0.25em] text-xs shadow-2xl transition-all transform active:scale-95 flex items-center justify-center gap-3">
            {loading ? <i className="fa-solid fa-circle-notch animate-spin"></i> : 'Authenticate Identity'}
          </button>
        </form>
      </Container>
    );
  }

  if (step === 'otp') {
    return (
      <Container>
        <div className="p-12 text-center">
          <div className="w-24 h-24 bg-orange-50 text-orange-600 rounded-[2.5rem] flex items-center justify-center mx-auto mb-10 text-4xl shadow-inner border border-orange-100">
            <i className="fa-solid fa-fingerprint"></i>
          </div>
          <h2 className="text-3xl font-black text-slate-900 tracking-tight leading-tight mb-3">Verification</h2>
          <p className="text-sm text-slate-500 font-medium mb-12 px-4">Enter token sent to <span className="font-black text-slate-900">{formData.mobile}</span></p>
          
          <form onSubmit={handleOtpSubmit}>
            <div className="flex justify-between gap-2 mb-12">
              {otp.map((digit, i) => (
                <input 
                  key={i} 
                  ref={(el) => { otpInputs.current[i] = el; }}
                  type="text" 
                  maxLength={1} 
                  value={digit}
                  onChange={(e) => handleOtpChange(i, e.target.value)}
                  onKeyDown={(e) => handleOtpKeyDown(i, e)}
                  className="w-12 h-16 text-center text-3xl font-black bg-slate-50 border-none rounded-2xl focus:ring-4 focus:ring-orange-100 outline-none shadow-inner transition-all" 
                />
              ))}
            </div>
            
            <button type="submit" disabled={loading} className="w-full py-6 bg-orange-600 hover:bg-orange-700 text-white rounded-3xl font-black uppercase tracking-[0.25em] text-xs shadow-[0_20px_40px_rgba(234,88,12,0.3)] transition-all transform active:scale-95">
               {loading ? <i className="fa-solid fa-circle-notch animate-spin"></i> : 'Secure Connect'}
            </button>
          </form>
          
          <p className="mt-10 text-[10px] text-slate-400 font-black uppercase tracking-widest cursor-pointer hover:text-blue-600 transition-colors">
            Request new token
          </p>
        </div>
      </Container>
    );
  }

  return (
    <Container>
      <div className="p-12 text-center animate-in fade-in zoom-in-95 duration-700">
        <div className="relative inline-block mb-10">
          <img src={profileImageUrl} className="w-32 h-32 rounded-[3rem] border-4 border-white mx-auto shadow-2xl transition-transform hover:scale-110 duration-500" alt="Profile" />
          <div className="absolute -bottom-2 -right-2 w-10 h-10 bg-emerald-500 rounded-2xl border-4 border-white flex items-center justify-center text-white shadow-lg">
             <i className="fa-solid fa-check text-sm"></i>
          </div>
        </div>
        <h2 className="text-3xl font-black text-slate-900 tracking-tight leading-none mb-3">नमस्ते, {formData.name}</h2>
        <p className="text-sm text-slate-500 font-medium mb-12">Select your jurisdictional location.</p>
        
        <form onSubmit={handleLocationSubmit} className="space-y-6 text-left">
          <button 
            type="button" 
            onClick={handleDetectLocation}
            className="w-full py-4 bg-blue-50 text-blue-600 rounded-3xl font-black uppercase tracking-widest text-[10px] flex items-center justify-center gap-2 hover:bg-blue-100 transition-all border border-blue-100"
          >
            {locationLoading ? (
               <i className="fa-solid fa-circle-notch animate-spin"></i>
            ) : (
              <><i className="fa-solid fa-location-crosshairs"></i> Auto-detect Location</>
            )}
          </button>

          <div className="space-y-2">
            <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] ml-1">Administrative District</label>
            <div className="relative">
              <select required value={formData.district} onChange={e => setFormData({...formData, district: e.target.value})} className="w-full px-6 py-4 rounded-3xl bg-slate-50 border-none focus:ring-4 focus:ring-blue-50/50 outline-none font-black text-slate-800 appearance-none shadow-inner cursor-pointer transition-all">
                <option value="">Select District</option>
                <option>Kathmandu</option><option>Lalitpur</option><option>Bhaktapur</option><option>Dhanusha</option><option>Parsa</option>
              </select>
            </div>
          </div>
          <div className="space-y-2">
            <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] ml-1">Local Palika / Ward</label>
            <input required placeholder="E.g., Kathmandu Metropolitan" value={formData.palika} onChange={e => setFormData({...formData, palika: e.target.value})} className="w-full px-6 py-4 rounded-3xl bg-slate-50 border-none focus:ring-4 focus:ring-blue-50/50 outline-none font-black text-slate-800 shadow-inner" />
          </div>
          <button className="w-full py-6 bg-blue-600 hover:bg-blue-700 text-white rounded-3xl font-black uppercase tracking-[0.25em] text-xs shadow-[0_20px_40px_rgba(37,99,235,0.3)] transition-all transform active:scale-95">
            Launch सुशासन
          </button>
        </form>
      </div>
    </Container>
  );
};

export default LoginPortal;
