
import React from 'react';
import { MOCK_LOGS } from '../constants';
import { Language } from '../types';
import { translations } from '../translations';

const TransparencyLog: React.FC<{ language: Language }> = ({ language }) => {
  const t = translations[language];

  return (
    <div className="bg-white rounded-[2.5rem] shadow-sm border border-slate-100 overflow-hidden max-w-4xl mx-auto">
      <div className="p-8 border-b border-slate-50 bg-slate-50/50 flex justify-between items-center">
        <div>
          <h3 className="text-xl font-black text-slate-800">{t.auditLogs}</h3>
          <p className="text-xs text-slate-500 font-medium mt-1">Immutable record of all official data entries and updates.</p>
        </div>
        <div className="bg-emerald-100 text-emerald-700 px-4 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-widest flex items-center gap-2">
           <i className="fa-solid fa-fingerprint"></i> VERIFIED
        </div>
      </div>
      <div className="divide-y divide-slate-50">
        {MOCK_LOGS.map((log) => (
          <div key={log.id} className="p-8 hover:bg-slate-50 transition-colors">
            <div className="flex justify-between items-start mb-4">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-slate-900 text-white flex items-center justify-center text-[10px] font-black uppercase">
                  {log.user.substring(0,2)}
                </div>
                <div>
                  <p className="text-sm font-black text-slate-800">{log.user}</p>
                  <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">{log.timestamp}</p>
                </div>
              </div>
              <span className="text-[10px] font-black text-blue-600 bg-blue-50 px-3 py-1 rounded-lg uppercase tracking-widest">
                {log.action}
              </span>
            </div>
            <p className="text-xs text-slate-600 font-medium pl-11">{log.details}</p>
          </div>
        ))}
      </div>
      <div className="p-6 bg-slate-900 text-center">
         <button className="text-white text-[10px] font-black uppercase tracking-[0.2em] hover:text-blue-400 transition-colors">
           Download Full Audit Log (PDF)
         </button>
      </div>
    </div>
  );
};

export default TransparencyLog;
